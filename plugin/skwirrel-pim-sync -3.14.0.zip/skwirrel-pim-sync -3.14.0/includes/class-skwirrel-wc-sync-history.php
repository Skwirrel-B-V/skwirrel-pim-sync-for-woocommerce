<?php
/**
 * Skwirrel Sync - Sync History Management.
 *
 * Manages sync history, last sync timestamps, and sync result storage.
 * All methods are static since they operate on WordPress options.
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Skwirrel_WC_Sync_History {

	/** @var string WordPress option key for the last sync timestamp. */
	public const OPTION_LAST_SYNC = 'skwirrel_wc_sync_last_sync';

	/** @var string WordPress option key for the last sync result array. */
	public const OPTION_LAST_SYNC_RESULT = 'skwirrel_wc_sync_last_result';

	/** @var string WordPress option key for the sync history array. */
	public const OPTION_SYNC_HISTORY = 'skwirrel_wc_sync_history';

	/** @var int Maximum number of history entries to keep. */
	public const MAX_HISTORY_ENTRIES = 20;

	/** @var string Transient key indicating a sync is currently in progress (UI badge). */
	public const SYNC_IN_PROGRESS = 'skwirrel_wc_sync_in_progress';

	/**
	 * Mutex transient owned exclusively by run_sync().
	 *
	 * Kept separate from SYNC_IN_PROGRESS so the admin dispatch path (handle_sync_now)
	 * can pre-set the UI badge without colliding with the concurrency guard.
	 *
	 * @var string
	 */
	public const SYNC_MUTEX = 'skwirrel_wc_sync_mutex';

	/** @var string Transient key used to signal the running sync to abort. */
	public const SYNC_ABORT = 'skwirrel_wc_sync_abort';

	/** @var int Time-to-live in seconds for the sync-in-progress / mutex transients. */
	public const HEARTBEAT_TTL = 60;

	/** @var string Option key for the sync phase progress array. */
	public const OPTION_SYNC_PROGRESS = 'skwirrel_wc_sync_progress';

	/** Phase identifiers. */
	public const PHASE_FETCH      = 'fetch';
	public const PHASE_PRODUCTS   = 'products';
	public const PHASE_TAXONOMY   = 'taxonomy';
	public const PHASE_ATTRIBUTES = 'attributes';
	public const PHASE_MEDIA      = 'media';
	public const PHASE_RELATIONS  = 'relations';
	public const PHASE_CLEANUP    = 'cleanup';

	/** Trigger types. */
	public const TRIGGER_MANUAL    = 'manual';
	public const TRIGGER_SCHEDULED = 'scheduled';
	public const TRIGGER_PURGE     = 'purge';

	/**
	 * Request the running sync to abort.
	 */
	public static function request_abort(): void {
		set_transient( self::SYNC_ABORT, '1', 300 );
	}

	/**
	 * Check if an abort has been requested and clear the flag.
	 *
	 * @return bool True if abort was requested.
	 */
	public static function is_abort_requested(): bool {
		if ( get_transient( self::SYNC_ABORT ) ) {
			delete_transient( self::SYNC_ABORT );
			return true;
		}
		return false;
	}

	/**
	 * Clear the abort flag (called at sync start).
	 */
	public static function clear_abort(): void {
		delete_transient( self::SYNC_ABORT );
	}

	/**
	 * Refresh the sync-in-progress transient so the UI knows the sync is still alive.
	 *
	 * If not refreshed within HEARTBEAT_TTL seconds, the transient expires automatically.
	 *
	 * @return void
	 */
	public static function sync_heartbeat(): void {
		$now = (string) time();
		set_transient( self::SYNC_IN_PROGRESS, $now, self::HEARTBEAT_TTL );
		set_transient( self::SYNC_MUTEX, $now, self::HEARTBEAT_TTL );
	}

	/**
	 * Whether a run's heartbeat is still fresh (a step ran within HEARTBEAT_TTL seconds).
	 *
	 * Read-only counterpart to acquire_sync_mutex(): the batched runner uses this to decide
	 * whether an existing run-state belongs to a live run (refuse a second start) or a stalled
	 * one (resume it), without taking the mutex.
	 */
	public static function is_heartbeat_fresh(): bool {
		$mutex = get_transient( self::SYNC_MUTEX );
		return is_numeric( $mutex ) && ( time() - (int) $mutex ) < self::HEARTBEAT_TTL;
	}

	/**
	 * Clear the UI "sync in progress" badge transient.
	 */
	public static function clear_sync_in_progress(): void {
		delete_transient( self::SYNC_IN_PROGRESS );
	}

	/**
	 * Acquire the run_sync() mutex if no fresh run is already in progress.
	 *
	 * A stored timestamp older than HEARTBEAT_TTL is treated as a dead prior run
	 * (the heartbeat refresh has lapsed) and is overwritten so the new run can take over.
	 *
	 * @return bool True if the mutex was acquired, false if another fresh run holds it.
	 */
	public static function acquire_sync_mutex(): bool {
		$mutex = get_transient( self::SYNC_MUTEX );
		if ( is_numeric( $mutex ) && ( time() - (int) $mutex ) < self::HEARTBEAT_TTL ) {
			return false;
		}
		set_transient( self::SYNC_MUTEX, (string) time(), self::HEARTBEAT_TTL );
		return true;
	}

	/**
	 * Release the run_sync() mutex.
	 *
	 * Called at the end of run_sync() (success or failure) so the next click can proceed.
	 */
	public static function release_sync_mutex(): void {
		delete_transient( self::SYNC_MUTEX );
	}

	/**
	 * Get the timestamp of the last completed sync.
	 *
	 * @return string|null ISO 8601 timestamp string, or null if no sync has been recorded.
	 */
	public static function get_last_sync(): ?string {
		return get_option( self::OPTION_LAST_SYNC, null );
	}

	/**
	 * Get the result array of the last completed sync.
	 *
	 * @return array|null Array with keys: success, created, updated, failed, trashed,
	 *                    categories_removed, error, with_attributes, without_attributes,
	 *                    trigger, timestamp.
	 *                    Returns null if no result has been recorded.
	 */
	public static function get_last_result(): ?array {
		return get_option( self::OPTION_LAST_SYNC_RESULT, null );
	}

	/**
	 * Get the sync history array (most recent first).
	 *
	 * @return array List of result arrays, each with keys: success, created, updated,
	 *               failed, trashed, categories_removed, error, with_attributes,
	 *               without_attributes, trigger, timestamp.
	 */
	public static function get_sync_history(): array {
		$history = get_option( self::OPTION_SYNC_HISTORY, [] );
		return is_array( $history ) ? $history : [];
	}

	/**
	 * Store the result of a sync run and append it to the history.
	 *
	 * Saves the result to the last-result option, prepends it to the history
	 * (capped at MAX_HISTORY_ENTRIES), and clears the sync-in-progress transient.
	 *
	 * @param bool   $ok                 Whether the sync completed successfully.
	 * @param int    $created            Number of products created.
	 * @param int    $updated            Number of products updated.
	 * @param int    $failed             Number of products that failed to sync.
	 * @param string $error              Error message (empty string if no error).
	 * @param int    $with_attrs         Number of products synced with attributes.
	 * @param int    $without_attrs      Number of products synced without attributes.
	 * @param int    $trashed            Number of stale products trashed.
	 * @param int    $categories_removed Number of stale categories removed.
	 * @param string $trigger            What initiated the sync: 'manual', 'scheduled', or 'purge'.
	 * @param string $log_file           Per-sync log filename (empty if none).
	 * @param int    $unchanged          Number of products skipped as unchanged.
	 * @param int    $deprecated         Number of products this run left in the deprecated status.
	 * @param string $run_id             Run uuid, for run-scoped product deep-links from the overview.
	 * @param string $warning            Non-fatal advisory for a successful run that deliberately
	 *                                   withheld an action (e.g. a refused mass removal).
	 *
	 * @return void
	 */
	public static function update_last_result(
		bool $ok,
		int $created,
		int $updated,
		int $failed,
		string $error = '',
		int $with_attrs = 0,
		int $without_attrs = 0,
		int $trashed = 0,
		int $categories_removed = 0,
		string $trigger = self::TRIGGER_MANUAL,
		string $log_file = '',
		int $unchanged = 0,
		int $deprecated = 0,
		string $run_id = '',
		string $warning = ''
	): void {
		$result = [
			'success'            => $ok,
			'created'            => $created,
			'updated'            => $updated,
			'unchanged'          => $unchanged,
			'failed'             => $failed,
			'trashed'            => $trashed,
			'deprecated'         => $deprecated,
			'categories_removed' => $categories_removed,
			'error'              => $error,
			// Non-fatal advisory for a run that succeeded but deliberately did not do something —
			// today: a removal refused by the mass-removal bound or by an incomplete membership sweep.
			'warning'            => $warning,
			'with_attributes'    => $with_attrs,
			'without_attributes' => $without_attrs,
			'trigger'            => $trigger,
			'timestamp'          => time(),
			'log_file'           => $log_file,
			'run_id'             => $run_id,
		];

		update_option( self::OPTION_LAST_SYNC_RESULT, $result, false );
		delete_transient( self::SYNC_IN_PROGRESS );
		self::release_sync_mutex();
		self::clear_sync_progress();

		// Clear slug resync flag after successful sync.
		if ( $ok ) {
			delete_option( 'skwirrel_wc_sync_slug_resync_needed' );
		}

		self::append_to_history( $result );
	}

	/**
	 * Add a history entry without updating the last sync result.
	 *
	 * Used for purge operations and other non-sync events that should appear
	 * in history but not overwrite the last sync status.
	 *
	 * @param array $entry History entry array (must include 'timestamp' and 'trigger').
	 * @return void
	 */
	public static function add_history_entry( array $entry ): void {
		self::append_to_history( $entry );
	}

	/**
	 * Delete a single log file by filename.
	 *
	 * Validates the filename to prevent directory traversal.
	 *
	 * @param string $filename Log file basename.
	 * @return void
	 */
	public static function delete_log_file( string $filename ): void {
		if ( ! preg_match( '/^sync-(manual|scheduled)-[\d-]+\.log$/', $filename ) ) {
			return;
		}
		$path = Skwirrel_WC_Sync_Logger::get_log_directory() . $filename;
		if ( file_exists( $path ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink -- Log file cleanup
			unlink( $path );
		}
	}

	/**
	 * Delete log files for the given history entries.
	 *
	 * Only deletes unique filenames (scheduled entries may share a daily log).
	 *
	 * @param array $entries History entries to clean up.
	 * @return void
	 */
	public static function delete_log_files_for_entries( array $entries ): void {
		$seen = [];
		foreach ( $entries as $entry ) {
			$file = $entry['log_file'] ?? '';
			if ( '' !== $file && ! isset( $seen[ $file ] ) ) {
				$seen[ $file ] = true;
				self::delete_log_file( $file );
			}
		}
	}

	/**
	 * Append an entry to the history array.
	 *
	 * @param array $entry History entry.
	 * @return void
	 */
	private static function append_to_history( array $entry ): void {
		$history = get_option( self::OPTION_SYNC_HISTORY, [] );
		if ( ! is_array( $history ) ) {
			$history = [];
		}

		// Prepend newest entry at the beginning
		array_unshift( $history, $entry );

		// Trim to MAX_HISTORY_ENTRIES — clean up log files for removed entries.
		if ( count( $history ) > self::MAX_HISTORY_ENTRIES ) {
			$removed = array_slice( $history, self::MAX_HISTORY_ENTRIES );
			$history = array_slice( $history, 0, self::MAX_HISTORY_ENTRIES );

			// Collect filenames still in use by remaining entries.
			$active_files = [];
			foreach ( $history as $h ) {
				$f = $h['log_file'] ?? '';
				if ( '' !== $f ) {
					$active_files[ $f ] = true;
				}
			}

			// Only delete files not still referenced by remaining entries.
			foreach ( $removed as $r ) {
				$f = $r['log_file'] ?? '';
				if ( '' !== $f && ! isset( $active_files[ $f ] ) ) {
					self::delete_log_file( $f );
				}
			}
		}

		update_option( self::OPTION_SYNC_HISTORY, $history, false );
	}

	/**
	 * Update the phase progress for the current sync.
	 *
	 * Stores progress in a non-autoloaded option so the admin UI can poll it.
	 * Also refreshes the heartbeat to keep the sync-in-progress transient alive.
	 *
	 * @param string $phase     Phase identifier (one of the PHASE_* constants).
	 * @param int    $current   Number of items processed in this phase.
	 * @param int    $total     Total items to process in this phase.
	 * @param string $label     Human-readable phase label.
	 * @return void
	 */
	public static function update_phase_progress( string $phase, int $current, int $total, string $label = '' ): void {
		$progress = get_option( self::OPTION_SYNC_PROGRESS, [] );
		if ( ! is_array( $progress ) ) {
			$progress = [];
		}

		$progress['current_phase'] = $phase;
		$progress['updated_at']    = time();

		if ( ! isset( $progress['phases'] ) || ! is_array( $progress['phases'] ) ) {
			$progress['phases'] = [];
		}

		$progress['phases'][ $phase ] = [
			'label'   => $label,
			'current' => $current,
			'total'   => $total,
			'status'  => $current >= $total && $total > 0 ? 'completed' : 'in_progress',
		];

		// Mark earlier phases as completed. Order matches the per-product-atomic flow:
		// categories/attributes/images are committed inside PHASE_PRODUCTS, so PHASE_TAXONOMY
		// and PHASE_ATTRIBUTES are no longer reported as separate phases.
		$phase_order = [ self::PHASE_FETCH, self::PHASE_PRODUCTS, self::PHASE_MEDIA, self::PHASE_RELATIONS, self::PHASE_CLEANUP ];
		$reached     = false;
		foreach ( $phase_order as $p ) {
			if ( $p === $phase ) {
				$reached = true;
				continue;
			}
			if ( ! $reached && isset( $progress['phases'][ $p ] ) ) {
				$progress['phases'][ $p ]['status'] = 'completed';
			}
		}

		update_option( self::OPTION_SYNC_PROGRESS, $progress, false );
		self::sync_heartbeat();
	}

	/**
	 * Get the current sync phase progress.
	 *
	 * @return array|null Progress array with 'current_phase' and 'phases', or null if not syncing.
	 */
	public static function get_sync_progress(): ?array {
		$progress = get_option( self::OPTION_SYNC_PROGRESS, null );
		return is_array( $progress ) ? $progress : null;
	}

	/**
	 * Clear the sync progress (called when sync completes or is reset).
	 *
	 * @return void
	 */
	public static function clear_sync_progress(): void {
		delete_option( self::OPTION_SYNC_PROGRESS );
	}

	/**
	 * Get the WordPress option key used to store the last sync timestamp.
	 *
	 * This is needed by the sync service to update the timestamp after a successful sync.
	 *
	 * @return string The option key for the last sync timestamp.
	 */
	public static function get_last_sync_option_key(): string {
		return self::OPTION_LAST_SYNC;
	}
}
