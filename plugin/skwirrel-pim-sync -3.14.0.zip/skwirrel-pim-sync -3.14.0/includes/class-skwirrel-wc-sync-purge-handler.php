<?php
/**
 * Skwirrel Sync Purge Handler.
 *
 * Centralises all purge logic: full purge (danger zone), stale product cleanup,
 * and stale category cleanup. Extracted from Admin_Settings and Sync_Service.
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Skwirrel_WC_Sync_Purge_Handler {

	/**
	 * Chunk size for bulk SQL operations to stay within MySQL packet limits.
	 */
	private const BULK_CHUNK_SIZE = 1000;

	/**
	 * Deprecated products advanced per batch during finalize.
	 *
	 * Each one is a WooCommerce save plus meta writes, so the batch is small enough that a step
	 * deadline is honoured promptly on a large discontinued catalogue.
	 */
	private const DEPRECATED_BATCH_SIZE = 100;

	/**
	 * Fraction of the Skwirrel-owned parent-product count above which a sweep-driven removal is
	 * refused rather than performed.
	 *
	 * A scheduled run removes products silently, so an upstream hiccup that returns a short (but
	 * technically successful) selection must not be able to empty the shop. For scale: 70 of 920
	 * (~8%) is a normal week on the reference install. Override with the
	 * `skwirrel_wc_sync_mass_removal_ratio` filter — deliberately not a setting.
	 */
	public const MASS_REMOVAL_RATIO = 0.25;

	/**
	 * Removal-set size at or below which the ratio bound is not applied at all.
	 *
	 * A ratio alone locks a small catalogue out of every removal forever: a shop with 2 Skwirrel
	 * products retiring 1 of them is a 50% removal, over any sane ratio, on every run. The bound
	 * exists to catch a mass event, and a handful of products is not one at any catalogue size.
	 */
	public const MASS_REMOVAL_FLOOR = 5;

	private Skwirrel_WC_Sync_Logger $logger;

	/**
	 * Constructor.
	 *
	 * @param Skwirrel_WC_Sync_Logger $logger Logger instance for recording purge activity.
	 */
	public function __construct( Skwirrel_WC_Sync_Logger $logger ) {
		$this->logger = $logger;
	}

	/**
	 * Purge all Skwirrel-managed data from WooCommerce.
	 *
	 * This is the "danger zone" full purge. Uses bulk SQL for attachments and products
	 * instead of per-item wp_delete_post/wp_delete_attachment calls — orders of magnitude
	 * faster on large stores. Media files on disk are left as orphans (use a media cleanup
	 * tool to reclaim space if needed).
	 *
	 * Steps performed:
	 * 1. Delete Skwirrel media attachment DB records via bulk SQL (files left on disk).
	 * 2. Find products with _skwirrel_external_id or _skwirrel_grouped_product_id meta,
	 *    collect their category term IDs and attribute taxonomy names.
	 * 3. Delete or trash products via bulk SQL (including WC lookup tables, comments, meta).
	 * 4. Delete Skwirrel categories via bulk SQL.
	 * 5. Delete product_brand and product_manufacturer terms via bulk SQL.
	 * 6. Delete all attribute taxonomies used by Skwirrel products (only if no remaining
	 *    non-trashed products use them) via bulk SQL.
	 * 7. Reset sync state options.
	 * 8. Flush object cache and store purge result.
	 *
	 * @param bool $permanent Whether to permanently delete products (true) or move them to trash (false).
	 * @return void
	 */
	public function purge_all( bool $permanent ): void {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,Squiz.PHP.DiscouragedFunctions.Discouraged -- long-running purge requires no time limit; @ guards against disable_functions
		}

		$mode_label = $permanent ? 'permanent delete' : 'trash';
		$this->logger->info( "Purge all Skwirrel products started (mode: {$mode_label})" );

		global $wpdb;

		// --- Step 1: Delete Skwirrel media attachment DB records ---
		// Files on disk are left as orphans (harmless) — use a media cleanup tool to reclaim space.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- bulk purge operation, no WP API equivalent
		$attachment_ids = array_map(
			'intval',
			$wpdb->get_col(
				"SELECT DISTINCT p.ID FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
				WHERE p.post_type = 'attachment'
				AND pm.meta_key = '_skwirrel_source_url'"
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		$attachments_deleted = count( $attachment_ids );
		if ( $attachments_deleted > 0 ) {
			$this->logger->info( "Purge: {$attachments_deleted} Skwirrel media attachments found, deleting DB records..." );
			$this->bulk_delete_post_records( $attachment_ids );
			$this->logger->info( "Purge: {$attachments_deleted} media attachments deleted (files left on disk as orphans)." );
		}

		// --- Step 2: Find products and collect their category term IDs ---
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- bulk purge operation, no WP API equivalent
		if ( $permanent ) {
			$product_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT DISTINCT p.ID FROM {$wpdb->posts} p
					INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
					WHERE p.post_type IN ('product', 'product_variation')
					AND p.post_status IN (%s, %s, %s, %s, %s, %s)
					AND pm.meta_key IN ('_skwirrel_external_id', '_skwirrel_grouped_product_id')",
					'publish',
					'draft',
					'pending',
					'private',
					'trash',
					Skwirrel_WC_Sync_Deprecated_Status::STATUS
				)
			);
		} else {
			$product_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT DISTINCT p.ID FROM {$wpdb->posts} p
					INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
					WHERE p.post_type IN ('product', 'product_variation')
					AND p.post_status IN (%s, %s, %s, %s, %s)
					AND pm.meta_key IN ('_skwirrel_external_id', '_skwirrel_grouped_product_id')",
					'publish',
					'draft',
					'pending',
					'private',
					Skwirrel_WC_Sync_Deprecated_Status::STATUS
				)
			);
		}
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		$product_ids = array_map( 'intval', $product_ids );

		// Also find variation children that may not have Skwirrel meta directly.
		$child_ids = [];
		if ( ! empty( $product_ids ) ) {
			foreach ( array_chunk( $product_ids, self::BULK_CHUNK_SIZE ) as $chunk ) {
				// Re-cast at the implode site so static analysers (Plugin Check)
				// can trace the int-only type into the SQL string. Redundant at
				// runtime — $product_ids was already array_map('intval') above.
				$ids = implode( ',', array_map( 'intval', $chunk ) );
				// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- IDs are intval-sanitized
				$child_ids = array_merge(
					$child_ids,
					array_map(
						'intval',
						$wpdb->get_col(
							"SELECT ID FROM {$wpdb->posts}
							WHERE post_parent IN ({$ids})
							AND post_type = 'product_variation'"
						)
					)
				);
				// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			}
		}
		$all_product_ids = array_values( array_unique( array_merge( $product_ids, $child_ids ) ) );

		// Collect category term IDs assigned to Skwirrel products BEFORE deleting them.
		$skwirrel_cat_term_ids = [];
		if ( ! empty( $all_product_ids ) ) {
			foreach ( array_chunk( $all_product_ids, self::BULK_CHUNK_SIZE ) as $chunk ) {
				$id_list = implode( ',', array_map( 'intval', $chunk ) );
				// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- IDs are intval-sanitized
				$skwirrel_cat_term_ids = array_merge(
					$skwirrel_cat_term_ids,
					$wpdb->get_col(
						"SELECT DISTINCT tt.term_id FROM {$wpdb->term_relationships} tr
						INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id AND tt.taxonomy = 'product_cat'
						WHERE tr.object_id IN ({$id_list})"
					)
				);
				// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			}
		}

		// Also collect categories with _skwirrel_category_id meta.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- bulk purge operation
		$meta_cat_term_ids = $wpdb->get_col(
			"SELECT tm.term_id FROM {$wpdb->termmeta} tm
			INNER JOIN {$wpdb->term_taxonomy} tt ON tm.term_id = tt.term_id AND tt.taxonomy = 'product_cat'
			WHERE tm.meta_key = '_skwirrel_category_id' AND tm.meta_value != ''"
		);

		$all_cat_term_ids = array_unique( array_map( 'intval', array_merge( $skwirrel_cat_term_ids, $meta_cat_term_ids ) ) );

		// --- Step 3: Delete or trash products via bulk SQL ---
		$deleted = count( $all_product_ids );
		if ( ! empty( $all_product_ids ) ) {
			$this->logger->info( "Purge: {$deleted} Skwirrel products found, processing..." );

			if ( $permanent ) {
				$this->bulk_delete_post_records( $all_product_ids );
			} else {
				$this->bulk_trash_post_records( $all_product_ids );
			}
		}
		$this->logger->info( "Purge: {$deleted} products processed (mode: {$mode_label})" );

		// --- Step 4: Delete Skwirrel-related categories via bulk SQL ---
		$default_cat_id     = (int) get_option( 'default_product_cat', 0 );
		$cat_ids_to_delete  = array_filter( $all_cat_term_ids, static fn( int $id ) => $id !== $default_cat_id );
		$categories_deleted = count( $cat_ids_to_delete );
		if ( $categories_deleted > 0 ) {
			$this->logger->info( "Purge: {$categories_deleted} Skwirrel categories found, deleting via SQL..." );
			$this->bulk_delete_terms( $cat_ids_to_delete, 'product_cat' );
			$this->logger->info( "Purge: {$categories_deleted} categories deleted." );
		}

		// --- Step 5: Delete product_brand and product_manufacturer terms via bulk SQL ---
		$brands_deleted        = 0;
		$manufacturers_deleted = 0;
		$purge_taxonomies      = [
			Skwirrel_WC_Sync_Brand_Sync::BRAND_TAXONOMY => &$brands_deleted,
			Skwirrel_WC_Sync_Brand_Sync::MANUFACTURER_TAXONOMY => &$manufacturers_deleted,
		];
		foreach ( $purge_taxonomies as $purge_tax => &$deleted_count ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- bulk purge operation
			$term_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT tt.term_id FROM {$wpdb->term_taxonomy} tt WHERE tt.taxonomy = %s",
					$purge_tax
				)
			);
			$term_ids = array_map( 'intval', $term_ids );
			if ( ! empty( $term_ids ) ) {
				$deleted_count = count( $term_ids );
				$this->logger->info( "Purge: {$deleted_count} {$purge_tax} terms found, deleting via SQL..." );
				$this->bulk_delete_terms( $term_ids, $purge_tax );
				$this->logger->info( "Purge: {$deleted_count} {$purge_tax} terms deleted." );
			}
		}
		unset( $deleted_count );

		// --- Step 6: Delete orphaned attribute taxonomies via bulk SQL ---
		// After Skwirrel products are removed, find ALL pa_* attribute taxonomies that have
		// zero remaining non-trashed products. This catches etim_*, skwirrel_variant, custom
		// class attributes, and any other attributes that were only used by Skwirrel products.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- bulk purge operation
		$all_attr_names = $wpdb->get_col(
			"SELECT attribute_name FROM {$wpdb->prefix}woocommerce_attribute_taxonomies"
		);

		$attributes_deleted = 0;
		if ( ! empty( $all_attr_names ) ) {
			// Resolve attribute IDs and delete terms + taxonomy registrations.
			$attr_ids = [];
			foreach ( $all_attr_names as $attr_name ) {
				$taxonomy = 'pa_' . $attr_name;

				// Only delete attributes that have NO remaining (non-trashed) products using them.
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- bulk purge operation
				$remaining = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT COUNT(*) FROM {$wpdb->term_relationships} tr
						INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
						INNER JOIN {$wpdb->posts} p ON tr.object_id = p.ID AND p.post_status NOT IN ('trash', 'auto-draft')
						WHERE tt.taxonomy = %s",
						$taxonomy
					)
				);
				if ( $remaining > 0 ) {
					$this->logger->verbose( "Purge: skipping attribute {$attr_name} — {$remaining} non-Skwirrel products still use it" );
					continue;
				}

				// Bulk delete all terms belonging to this attribute taxonomy.
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- bulk purge operation
				$attr_term_ids = $wpdb->get_col(
					$wpdb->prepare(
						"SELECT tt.term_id FROM {$wpdb->term_taxonomy} tt WHERE tt.taxonomy = %s",
						$taxonomy
					)
				);
				if ( ! empty( $attr_term_ids ) ) {
					$this->bulk_delete_terms( array_map( 'intval', $attr_term_ids ), $taxonomy );
				}

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- bulk purge operation
				$attr_id = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT attribute_id FROM {$wpdb->prefix}woocommerce_attribute_taxonomies WHERE attribute_name = %s",
						$attr_name
					)
				);
				if ( $attr_id > 0 ) {
					$attr_ids[] = $attr_id;
				}
				++$attributes_deleted;
			}

			// Bulk delete the attribute taxonomy registrations.
			if ( ! empty( $attr_ids ) ) {
				$this->logger->info( "Purge: {$attributes_deleted} Skwirrel attribute taxonomies found, deleting via SQL..." );
				foreach ( array_chunk( $attr_ids, self::BULK_CHUNK_SIZE ) as $chunk ) {
					$ids = implode( ',', array_map( 'intval', $chunk ) );
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- IDs are intval-sanitized
					$wpdb->query( "DELETE FROM {$wpdb->prefix}woocommerce_attribute_taxonomies WHERE attribute_id IN ({$ids})" );
				}
				delete_transient( 'wc_attribute_taxonomies' );
				wp_cache_delete( 'woocommerce-attributes', 'woocommerce' );
				$this->logger->info( "Purge: {$attributes_deleted} attribute taxonomies deleted." );
			}
		}

		// --- Step 7: Reset sync state options ---
		delete_option( 'skwirrel_wc_sync_last_sync' );
		delete_option( 'skwirrel_wc_sync_force_full_sync' );
		$this->logger->info( 'Purge: sync state options reset — last_sync checkpoint cleared, force_full_sync flag cleared, last sync result preserved. Next sync will run as initial full pass.' );

		// --- Step 8: Flush caches and store purge result ---
		wp_cache_flush();

		$this->logger->info( "Purge completed: {$deleted} products, {$attachments_deleted} media, {$categories_deleted} categories, {$brands_deleted} brands, {$manufacturers_deleted} manufacturers, {$attributes_deleted} attributes (mode: {$mode_label})" );

		$purge_result = [
			'timestamp'     => time(),
			'mode'          => $mode_label,
			'products'      => $deleted,
			'attachments'   => $attachments_deleted,
			'categories'    => $categories_deleted,
			'brands'        => $brands_deleted,
			'manufacturers' => $manufacturers_deleted,
			'attributes'    => $attributes_deleted,
		];

		update_option( 'skwirrel_wc_sync_last_purge', $purge_result, false );

		// Add purge to sync history so it's visible in the history table.
		Skwirrel_WC_Sync_History::add_history_entry(
			[
				'success'            => true,
				'trigger'            => Skwirrel_WC_Sync_History::TRIGGER_PURGE,
				'created'            => 0,
				'updated'            => 0,
				'failed'             => 0,
				'trashed'            => $deleted,
				'categories_removed' => $categories_deleted,
				'with_attributes'    => 0,
				'without_attributes' => 0,
				'error'              => '',
				'purge_mode'         => $mode_label,
				'purge_attachments'  => $attachments_deleted,
				'purge_brands'       => $brands_deleted,
				'purge_attributes'   => $attributes_deleted,
				'timestamp'          => time(),
			]
		);
	}

	/**
	 * Bulk delete post records and all related data via direct SQL.
	 *
	 * Deletes in correct order: WC lookup tables → comments/commentmeta →
	 * term_relationships → postmeta → posts. Operates in chunks to stay
	 * within MySQL packet size limits.
	 *
	 * @param int[] $post_ids Post IDs to permanently delete.
	 * @return void
	 */
	private function bulk_delete_post_records( array $post_ids ): void {
		if ( empty( $post_ids ) ) {
			return;
		}

		global $wpdb;

		foreach ( array_chunk( $post_ids, self::BULK_CHUNK_SIZE ) as $chunk ) {
			$ids = implode( ',', array_map( 'intval', $chunk ) );

			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- bulk purge with intval-sanitized IDs

			// WooCommerce product lookup tables.
			$wpdb->query( "DELETE FROM {$wpdb->prefix}wc_product_meta_lookup WHERE product_id IN ({$ids})" );
			$wpdb->query( "DELETE FROM {$wpdb->prefix}wc_product_attributes_lookup WHERE product_id IN ({$ids})" );

			// Comment meta (must precede comments deletion).
			$wpdb->query(
				"DELETE cm FROM {$wpdb->commentmeta} cm
				INNER JOIN {$wpdb->comments} c ON cm.comment_id = c.comment_ID
				WHERE c.comment_post_ID IN ({$ids})"
			);
			$wpdb->query( "DELETE FROM {$wpdb->comments} WHERE comment_post_ID IN ({$ids})" );

			// Term relationships (product → category/brand/attribute assignments).
			$wpdb->query( "DELETE FROM {$wpdb->term_relationships} WHERE object_id IN ({$ids})" );

			// Post meta and posts.
			$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE post_id IN ({$ids})" );
			$wpdb->query( "DELETE FROM {$wpdb->posts} WHERE ID IN ({$ids})" );

			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}
	}

	/**
	 * Bulk trash post records via direct SQL.
	 *
	 * Stores original post_status for potential un-trash, sets status to 'trash',
	 * and removes entries from WC lookup tables (WC excludes trashed products).
	 *
	 * @param int[] $post_ids Post IDs to move to trash.
	 * @return void
	 */
	private function bulk_trash_post_records( array $post_ids ): void {
		if ( empty( $post_ids ) ) {
			return;
		}

		global $wpdb;
		$now = time();

		foreach ( array_chunk( $post_ids, self::BULK_CHUNK_SIZE ) as $chunk ) {
			$ids = implode( ',', array_map( 'intval', $chunk ) );

			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- bulk purge with intval-sanitized IDs

			// Store original status for un-trash support.
			$wpdb->query(
				"INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value)
				SELECT ID, '_wp_trash_meta_status', post_status
				FROM {$wpdb->posts} WHERE ID IN ({$ids})"
			);
			$wpdb->query(
				$wpdb->prepare(
					"INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value)
					SELECT ID, '_wp_trash_meta_time', %s
					FROM {$wpdb->posts} WHERE ID IN ({$ids})",
					(string) $now
				)
			);

			// Move to trash.
			$wpdb->query( "UPDATE {$wpdb->posts} SET post_status = 'trash' WHERE ID IN ({$ids})" );

			// Remove from WC lookup tables (WC excludes trashed products from queries).
			$wpdb->query( "DELETE FROM {$wpdb->prefix}wc_product_meta_lookup WHERE product_id IN ({$ids})" );
			$wpdb->query( "DELETE FROM {$wpdb->prefix}wc_product_attributes_lookup WHERE product_id IN ({$ids})" );

			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}
	}

	/**
	 * Bulk delete taxonomy terms and all related data via direct SQL.
	 *
	 * Deletes in correct order: term_relationships → termmeta → term_taxonomy → terms.
	 * Also recounts term_taxonomy counts for affected taxonomies.
	 *
	 * @param int[]  $term_ids Term IDs to permanently delete.
	 * @param string $taxonomy Taxonomy name (for targeted term_taxonomy deletion).
	 * @return void
	 */
	private function bulk_delete_terms( array $term_ids, string $taxonomy ): void {
		if ( empty( $term_ids ) ) {
			return;
		}

		global $wpdb;

		foreach ( array_chunk( $term_ids, self::BULK_CHUNK_SIZE ) as $chunk ) {
			$ids = implode( ',', array_map( 'intval', $chunk ) );

			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- bulk purge with intval-sanitized IDs

			// Remove term ↔ object relationships.
			$wpdb->query(
				"DELETE tr FROM {$wpdb->term_relationships} tr
				INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
				WHERE tt.term_id IN ({$ids})"
			);

			// Remove term meta.
			$wpdb->query( "DELETE FROM {$wpdb->termmeta} WHERE term_id IN ({$ids})" );

			// Remove term_taxonomy rows (scoped to taxonomy for safety).
			$wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$wpdb->term_taxonomy} WHERE term_id IN ({$ids}) AND taxonomy = %s",
					$taxonomy
				)
			);

			// Remove terms themselves (only if no other taxonomy references remain).
			$wpdb->query(
				"DELETE t FROM {$wpdb->terms} t
				LEFT JOIN {$wpdb->term_taxonomy} tt ON t.term_id = tt.term_id
				WHERE t.term_id IN ({$ids}) AND tt.term_id IS NULL"
			);

			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}

		clean_term_cache( $term_ids, $taxonomy );
	}

	/**
	 * Purge stale products that were not updated during the current sync run.
	 *
	 * Finds products with _skwirrel_external_id or _skwirrel_grouped_product_id meta
	 * where _skwirrel_synced_at is either missing or older than the sync start timestamp.
	 * Stale products (and their variations) are moved to the trash.
	 *
	 * Safety: the synced_at meta value is validated as numeric before comparison to
	 * prevent corrupt meta values from causing incorrect trashing.
	 *
	 * This is only the DETECTION. Whether the resulting set may actually be removed is decided by
	 * apply_missing_state(), the single chokepoint every removal passes through — which is why the
	 * explicit facts (`$human_initiated`, `$membership_complete`) are required arguments here rather
	 * than something this method infers from being "the full-sync path".
	 *
	 * @param int                             $sync_started_at     Unix timestamp when the sync run started.
	 * @param Skwirrel_WC_Sync_Product_Mapper $mapper              Product mapper instance (for meta key accessors).
	 * @param string                          $run_id              Current run uuid, for the deep-link marker.
	 * @param bool                            $human_initiated     Whether a person started this run.
	 * @param bool                            $membership_complete Whether the membership picture is complete.
	 * @param float|null                      $ratio               Mass-removal bound; null uses the filtered default.
	 * @return array{trashed:int, refused:bool, message:string}
	 */
	public function purge_stale_products( int $sync_started_at, Skwirrel_WC_Sync_Product_Mapper $mapper, string $run_id, bool $human_initiated, bool $membership_complete, ?float $ratio = null ): array {
		global $wpdb;
		$external_id_meta = $mapper->get_external_id_meta_key();
		$synced_at_meta   = $mapper->get_synced_at_meta_key();

		// Products no longer present in the feed are moved to trash. Whether this cleanup runs at
		// all is governed solely by the visible "Clean up deleted products after full sync" option
		// (checked by the caller) — there is no separate hidden state mapping.
		$missing_state = 'trash';

		// Find products with _skwirrel_external_id that were NOT updated during this sync.
		// Safety check: meta_value must be numeric (prevent corrupt data from causing incorrect trashing).
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$stale_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT pm_ext.post_id
             FROM {$wpdb->postmeta} pm_ext
             INNER JOIN {$wpdb->posts} p ON pm_ext.post_id = p.ID
                 AND p.post_status NOT IN ('trash', 'auto-draft')
                 AND p.post_type IN ('product', 'product_variation')
             LEFT JOIN {$wpdb->postmeta} pm_sync ON pm_ext.post_id = pm_sync.post_id
                 AND pm_sync.meta_key = %s
             WHERE pm_ext.meta_key = %s
                 AND pm_ext.meta_value != ''
                 AND (
                     pm_sync.meta_value IS NULL
                     OR (pm_sync.meta_value REGEXP '^[0-9]+$' AND CAST(pm_sync.meta_value AS UNSIGNED) < %d)
                 )",
				$synced_at_meta,
				$external_id_meta,
				$sync_started_at
			)
		);

		// Find variable products (grouped products) that were not updated during this sync.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$stale_variable_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT pm_grp.post_id
             FROM {$wpdb->postmeta} pm_grp
             INNER JOIN {$wpdb->posts} p ON pm_grp.post_id = p.ID
                 AND p.post_status NOT IN ('trash', 'auto-draft')
                 AND p.post_type = 'product'
             LEFT JOIN {$wpdb->postmeta} pm_sync ON pm_grp.post_id = pm_sync.post_id
                 AND pm_sync.meta_key = %s
             WHERE pm_grp.meta_key = %s
                 AND pm_grp.meta_value != ''
                 AND (
                     pm_sync.meta_value IS NULL
                     OR (pm_sync.meta_value REGEXP '^[0-9]+$' AND CAST(pm_sync.meta_value AS UNSIGNED) < %d)
                 )",
				$synced_at_meta,
				Skwirrel_WC_Sync_Product_Lookup::GROUPED_PRODUCT_ID_META,
				$sync_started_at
			)
		);

		$all_stale = array_unique(
			array_merge(
				array_map( 'intval', $stale_ids ),
				array_map( 'intval', $stale_variable_ids )
			)
		);

		if ( empty( $all_stale ) ) {
			$this->logger->verbose( 'No stale products found' );
			return [
				'trashed' => 0,
				'refused' => false,
				'message' => '',
			];
		}

		// Log pre-purge summary
		$this->logger->info(
			'Stale products detected',
			[
				'count'           => count( $all_stale ),
				'product_ids'     => array_slice( $all_stale, 0, 20 ),
				'sync_started_at' => gmdate( 'Y-m-d H:i:s', $sync_started_at ),
			]
		);

		return $this->apply_missing_state(
			$all_stale,
			$this->count_stale_purge_universe( $external_id_meta ),
			$human_initiated,
			$membership_complete,
			'synced_at',
			$missing_state,
			$run_id,
			$ratio
		);
	}

	/**
	 * THE removal chokepoint: authorise a set of missing products, then retire them.
	 *
	 * Every "this product is gone, retire it" decision in the sync run goes through here, and the
	 * safety checks live INSIDE it rather than at the call sites. That is deliberate and structural:
	 * a new detection path cannot reach a removal without inheriting the bound, because there is no
	 * other code that writes the missing-state. Adding a guard at a caller instead would only guard
	 * the callers that exist today.
	 *
	 * The guard's inputs are explicit facts supplied by whoever knows them — never re-derived here
	 * from delta/full, the trigger name, or anything else that merely correlates today. Every one of
	 * them fails CLOSED: an unknown, absent or incoherent signal means remove nothing.
	 *
	 *  - `$membership_complete` (from the sweep) is a hard precondition and is never bypassable.
	 *    Absence cannot be proven from an incomplete picture, no matter who asked.
	 *  - `$human_initiated` (from the run's trigger) bypasses only the MAGNITUDE bound — that is the
	 *    deliberate escape hatch: a person who asked for the sync sees the result and can act on it.
	 *    An unattended run never gets it.
	 *  - An incoherent denominator (fewer owned products than candidates) means the caller measured
	 *    two different universes, so the ratio would be meaningless — refuse rather than guess.
	 *
	 * NB: the deprecated-lifecycle escalation deliberately does NOT come through here. It is not an
	 * inference about selection membership — it is an explicit per-product countdown that the admin
	 * configured via `deprecated_remove_after_syncs`, and its cadence is frozen by the GH-40 spec.
	 *
	 * @param array<int, int> $candidate_ids       Product/variation IDs judged missing.
	 * @param int             $owned_count         Size of the universe those candidates were drawn from.
	 * @param bool            $human_initiated     Whether a person started this run (explicit fact).
	 * @param bool            $membership_complete Whether the membership picture covers every
	 *                                             configured selection (explicit fact).
	 * @param string          $detection           Which detection produced the set, for logging.
	 * @param string          $missing_state       Post status to apply (always `trash` today).
	 * @param string          $run_id              Current run uuid, for the deep-link marker.
	 * @param float|null      $ratio               Mass-removal bound; null uses the filtered default.
	 * @return array{trashed:int, refused:bool, message:string} Posts actually changed, whether the
	 *                                             removal was refused, and the reason to surface.
	 */
	private function apply_missing_state(
		array $candidate_ids,
		int $owned_count,
		bool $human_initiated,
		bool $membership_complete,
		string $detection,
		string $missing_state,
		string $run_id,
		?float $ratio = null
	): array {
		$none = [
			'trashed' => 0,
			'refused' => false,
			'message' => '',
		];

		// Precondition 1 — the membership picture must be complete. Not bypassable by anyone.
		if ( ! $membership_complete ) {
			$message = __( 'Removal skipped: the product membership picture for this run is incomplete, so no product can be proven to have left the selection. The product sync itself finished normally.', 'skwirrel-pim-sync' );
			$this->logger->warning(
				$message,
				[
					'detection'  => $detection,
					'candidates' => count( $candidate_ids ),
				]
			);
			return [
				'trashed' => 0,
				'refused' => true,
				'message' => $message,
			];
		}

		$candidate_ids = array_values( array_unique( array_map( 'intval', $candidate_ids ) ) );
		$missing_count = count( $candidate_ids );
		if ( 0 === $missing_count ) {
			return $none;
		}

		// Precondition 2 — the denominator must contain the candidates. If it does not, the caller
		// counted two different universes and the ratio below would be nonsense.
		if ( $owned_count < $missing_count ) {
			$message = __( 'Removal skipped: the removal set could not be measured against the catalogue it came from. Nothing was removed.', 'skwirrel-pim-sync' );
			$this->logger->warning(
				$message,
				[
					'detection' => $detection,
					'missing'   => $missing_count,
					'owned'     => $owned_count,
				]
			);
			return [
				'trashed' => 0,
				'refused' => true,
				'message' => $message,
			];
		}

		// Precondition 3 — magnitude. Only a human-initiated run may exceed it.
		$bound = null === $ratio ? self::get_mass_removal_ratio() : $ratio;
		if ( ! $human_initiated && self::exceeds_mass_removal( $missing_count, $owned_count, $bound ) ) {
			$message = sprintf(
				/* translators: 1: number of products, 2: total Skwirrel-managed products, 3: percentage of the catalogue, 4: allowed percentage */
				__( 'Mass removal refused: %1$d of %2$d Skwirrel products (%3$s%%) are no longer in the selection, which exceeds the %4$s%% safety limit. Nothing was removed. Run a manual sync to apply it.', 'skwirrel-pim-sync' ),
				$missing_count,
				$owned_count,
				(string) round( ( $missing_count / $owned_count ) * 100, 1 ),
				(string) round( $bound * 100, 1 )
			);
			$this->logger->warning(
				$message,
				[
					'detection'   => $detection,
					'missing'     => $missing_count,
					'owned'       => $owned_count,
					'ratio'       => round( $missing_count / $owned_count, 4 ),
					'limit_ratio' => $bound,
					'product_ids' => array_slice( $candidate_ids, 0, 20 ),
				]
			);
			return [
				'trashed' => 0,
				'refused' => true,
				'message' => $message,
			];
		}

		$trashed = 0;
		foreach ( $candidate_ids as $post_id ) {
			$product = wc_get_product( $post_id );
			if ( ! $product ) {
				$this->logger->verbose( 'Missing product not found in WooCommerce, skipped', [ 'wc_id' => $post_id ] );
				continue;
			}

			// Already in the target state from an earlier run: do not re-save it (and re-inflate the
			// count) on every subsequent run — a stale product keeps its old _skwirrel_synced_at and
			// would otherwise match forever. The variation cascade below still runs: a parent trashed
			// by a previous run that died mid-loop, or trashed by hand, can sit in the target state
			// while its variations are still published and purchasable.
			$parent_handled = ( $product->get_status() === $missing_state );

			if ( ! $parent_handled ) {
				$this->logger->info(
					'Product no longer in the Skwirrel selection — retiring it',
					[
						'wc_id' => $post_id,
						'sku'   => $product->get_sku(),
						'name'  => $product->get_name(),
						'type'  => $product->get_type(),
						'state' => $missing_state,
					]
				);

				$product->set_status( $missing_state );
				$product->save();
				$this->reset_deprecated_counter_on_entry( (int) $post_id, $missing_state );
				// Invalidate every change gate: if this hidden product later reappears unchanged, the
				// timestamp, content-hash, group and virtual gates can each return `unchanged` on their
				// own — before the revive logic — and it would never come back.
				Skwirrel_WC_Sync_Product_Upserter::invalidate_change_gates( (int) $post_id );
				Skwirrel_WC_Sync_Run_Links::mark_trashed( (int) $post_id, $run_id );
				++$trashed;
			}

			// Variable product: also apply the state to its variations.
			if ( $product->is_type( 'variable' ) ) {
				$variation_ids = $product->get_children();
				foreach ( $variation_ids as $vid ) {
					$variation = wc_get_product( $vid );
					if ( $variation && $missing_state !== $variation->get_status() ) {
						$variation->set_status( $missing_state );
						$variation->save();
						$this->reset_deprecated_counter_on_entry( (int) $vid, $missing_state );
						Skwirrel_WC_Sync_Product_Upserter::invalidate_change_gates( (int) $vid );
						Skwirrel_WC_Sync_Run_Links::mark_trashed( (int) $vid, $run_id );
						++$trashed;
					}
				}
			}
		}

		if ( $trashed > 0 ) {
			$this->logger->info(
				'Products no longer in the Skwirrel selection cleaned up',
				[
					'count'     => $trashed,
					'detection' => $detection,
				]
			);
		}

		return [
			'trashed' => $trashed,
			'refused' => false,
			'message' => '',
		];
	}

	/**
	 * Count the live, Skwirrel-owned posts that the stale-purge detection draws from.
	 *
	 * Deliberately the same joins, statuses, post types and meta keys as the two stale queries,
	 * minus the staleness clause — so the stale set is always a subset of this count and the
	 * chokepoint's ratio compares like with like.
	 *
	 * @param string $external_id_meta External-id meta key.
	 */
	private function count_stale_purge_universe( string $external_id_meta ): int {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT pm.post_id)
                 FROM {$wpdb->postmeta} pm
                 INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
                     AND p.post_status NOT IN ('trash', 'auto-draft')
                     AND p.post_type IN ('product', 'product_variation')
                 WHERE pm.meta_key IN (%s, %s)
                     AND pm.meta_value != ''",
				$external_id_meta,
				Skwirrel_WC_Sync_Product_Lookup::GROUPED_PRODUCT_ID_META
			)
		);
	}

	/**
	 * Select the products whose Skwirrel product id is absent from the sweep set.
	 *
	 * Pure: no WordPress, no database — the removal decision is the highest-risk part of the run,
	 * so it is unit-testable on its own.
	 *
	 * @param array<int, int>  $owned     Map of WooCommerce post id => Skwirrel product id.
	 * @param array<int, bool> $sweep_ids Sweep membership set, Skwirrel product id => true.
	 * @return array<int, int> WooCommerce post ids to retire (list, re-indexed).
	 */
	public static function select_missing_ids( array $owned, array $sweep_ids ): array {
		$missing = [];
		foreach ( $owned as $post_id => $product_id ) {
			// A product with no usable Skwirrel id cannot be proven absent — never remove it.
			if ( (int) $product_id <= 0 ) {
				continue;
			}
			if ( ! isset( $sweep_ids[ (int) $product_id ] ) ) {
				$missing[] = (int) $post_id;
			}
		}
		return $missing;
	}

	/**
	 * Whether a removal set is large enough to be refused rather than performed.
	 *
	 * Pure. A removal at or below MASS_REMOVAL_FLOOR is never refused, whatever the ratio says; a
	 * ratio of 1 or more can never be exceeded and so disables the bound entirely.
	 *
	 * @param int        $missing_count Products the sweep says have left the selection.
	 * @param int        $owned_count   Skwirrel-owned parent products currently live in the shop.
	 * @param float|null $ratio         Bound to apply; null uses MASS_REMOVAL_RATIO via its filter.
	 */
	public static function exceeds_mass_removal( int $missing_count, int $owned_count, ?float $ratio = null ): bool {
		// Nothing to remove, or no denominator to measure against: never divide, never refuse.
		if ( $missing_count <= 0 || $owned_count <= 0 ) {
			return false;
		}
		// A handful of products is not a mass event, however small the catalogue it came from.
		if ( $missing_count <= self::MASS_REMOVAL_FLOOR ) {
			return false;
		}
		$bound = null === $ratio ? self::get_mass_removal_ratio() : $ratio;
		return ( $missing_count / $owned_count ) > $bound;
	}

	/**
	 * The active mass-removal bound.
	 *
	 * Exposed as a filter rather than a setting: it is a safety rail, not a preference, and a store
	 * that genuinely wants a bigger removal can perform it with a manual sync.
	 */
	public static function get_mass_removal_ratio(): float {
		return (float) apply_filters( 'skwirrel_wc_sync_mass_removal_ratio', self::MASS_REMOVAL_RATIO );
	}

	/**
	 * Retire the products that the membership sweep says have left the Skwirrel selection.
	 *
	 * Detection here is driven by the sweep diff rather than by `_skwirrel_synced_at`, which is what
	 * makes it usable on a delta run: a delta payload never contains every live product, so absence
	 * from the payload proves nothing, while absence from the sweep does.
	 *
	 * Only parent products (`post_type = 'product'`) carrying `_skwirrel_product_id` are diffed.
	 * Variations do not hold a selection membership of their own — they descend from a virtual
	 * product — so diffing them would mark every variation as missing; a retired variable parent
	 * cascades to its children in apply_missing_state() instead.
	 *
	 * This is only the DETECTION — removal guards live in apply_missing_state() and the service's
	 * explicit scheduled-empty check. A complete empty set is authoritative for a manual run, which
	 * is the human escape hatch for intentionally clearing a selection.
	 *
	 * @param array<int, bool>                $sweep_ids           Sweep membership set, Skwirrel product id => true.
	 * @param Skwirrel_WC_Sync_Product_Mapper $mapper              Product mapper (for the meta key accessor).
	 * @param string                          $run_id              Current run uuid, for the deep-link marker.
	 * @param bool                            $human_initiated     Whether a person started this run.
	 * @param bool                            $membership_complete Whether the sweep covered every selection.
	 * @param float|null                      $ratio               Mass-removal bound; null uses the filtered default.
	 * @return array{trashed:int, missing:int, owned:int, refused:bool, message:string}
	 */
	public function purge_missing_from_sweep( array $sweep_ids, Skwirrel_WC_Sync_Product_Mapper $mapper, string $run_id, bool $human_initiated, bool $membership_complete, ?float $ratio = null ): array {
		global $wpdb;

		$product_id_meta = $mapper->get_product_id_meta_key();
		$missing_state   = 'trash';

		$empty = [
			'trashed' => 0,
			'missing' => 0,
			'owned'   => 0,
			'refused' => false,
			'message' => '',
		];

		// Live, Skwirrel-owned parent products and the Skwirrel id each one claims. Trashed and
		// auto-draft posts are excluded so an already-retired product is not re-counted forever.
		// The numeric guard mirrors the stale-purge SQL: corrupt meta is skipped, never cast.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT pm.post_id, pm.meta_value AS skwirrel_product_id
                 FROM {$wpdb->postmeta} pm
                 INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
                     AND p.post_status NOT IN ('trash', 'auto-draft')
                     AND p.post_type = 'product'
                 WHERE pm.meta_key = %s
                     AND pm.meta_value REGEXP '^[0-9]+$'",
				$product_id_meta
			)
		);
		if ( null === $rows && '' !== (string) $wpdb->last_error ) {
			$message = __( 'Removal skipped: the product membership could not be read from the database safely. Nothing was removed.', 'skwirrel-pim-sync' );
			$this->logger->warning( $message, [ 'database_error' => (string) $wpdb->last_error ] );
			return array_merge(
				$empty,
				[
					'refused' => true,
					'message' => $message,
				]
			);
		}

		$owned               = [];
		$conflicting_meta    = false;
		$conflicting_post_id = 0;
		$invalid_meta        = false;
		foreach ( (array) $rows as $row ) {
			$post_id    = (int) $row->post_id;
			$product_id = self::normalize_positive_id( $row->skwirrel_product_id );
			if ( $post_id <= 0 || null === $product_id ) {
				$invalid_meta        = true;
				$conflicting_post_id = $post_id;
				break;
			}
			if ( isset( $owned[ $post_id ] ) && $owned[ $post_id ] !== $product_id ) {
				$conflicting_meta    = true;
				$conflicting_post_id = $post_id;
				break;
			}
			$owned[ $post_id ] = $product_id;
		}
		unset( $rows );

		if ( $invalid_meta ) {
			$message = __( 'Removal skipped: a product has an invalid Skwirrel product ID, so its selection membership cannot be determined safely. Nothing was removed.', 'skwirrel-pim-sync' );
			$this->logger->warning( $message, [ 'wc_id' => $conflicting_post_id ] );
			return array_merge(
				$empty,
				[
					'refused' => true,
					'message' => $message,
				]
			);
		}

		if ( $conflicting_meta ) {
			$message = __( 'Removal skipped: a product has conflicting Skwirrel product IDs, so its selection membership cannot be determined safely. Nothing was removed.', 'skwirrel-pim-sync' );
			$this->logger->warning( $message, [ 'wc_id' => $conflicting_post_id ] );
			return array_merge(
				$empty,
				[
					'refused' => true,
					'message' => $message,
				]
			);
		}

		$owned_count = count( $owned );
		$missing     = self::select_missing_ids( $owned, $sweep_ids );

		$missing_count = count( $missing );
		if ( $missing_count > 0 ) {
			$this->logger->info(
				'Products no longer in the Skwirrel selection detected by the membership sweep',
				[
					'count'       => $missing_count,
					'owned'       => $owned_count,
					'product_ids' => array_slice( $missing, 0, 20 ),
				]
			);
		}

		$outcome = $this->apply_missing_state(
			$missing,
			$owned_count,
			$human_initiated,
			$membership_complete,
			'sweep',
			$missing_state,
			$run_id,
			$ratio
		);

		return array_merge(
			$empty,
			$outcome,
			[
				'missing' => $missing_count,
				'owned'   => $owned_count,
			]
		);
	}

	/**
	 * Normalize a database identifier without allowing integer overflow or lossy casts.
	 *
	 * @param mixed $value Candidate identifier.
	 */
	private static function normalize_positive_id( $value ): ?int {
		if ( is_int( $value ) ) {
			return $value > 0 ? $value : null;
		}
		if ( is_string( $value ) && ctype_digit( $value ) ) {
			$digits = ltrim( $value, '0' );
			if ( '' === $digits ) {
				return null;
			}
			$max = (string) PHP_INT_MAX;
			if ( strlen( $digits ) > strlen( $max ) || ( strlen( $digits ) === strlen( $max ) && strcmp( $digits, $max ) > 0 ) ) {
				return null;
			}
			return (int) $digits;
		}
		return null;
	}

	/**
	 * Start the deprecated counter fresh when a stale product newly enters the deprecated status via
	 * the __missing__ path. Mirrors the upsert reset-on-entry so a stale count left over from a prior
	 * deprecation period is never reused (which would trash the product early). No-op otherwise.
	 *
	 * The callers only invoke this on a genuine state change (guarded against "already in this state"),
	 * so reaching here with `deprecated` always means a fresh entry.
	 *
	 * @param int    $post_id       The product/variation ID just set to $applied_state.
	 * @param string $applied_state The missing-state just applied.
	 */
	private function reset_deprecated_counter_on_entry( int $post_id, string $applied_state ): void {
		if ( Skwirrel_WC_Sync_Deprecated_Status::STATUS === $applied_state ) {
			delete_post_meta( $post_id, Skwirrel_WC_Sync_Deprecated_Status::COUNT_META );
			delete_post_meta( $post_id, Skwirrel_WC_Sync_Deprecated_Status::TICKED_META );
		}
	}

	/**
	 * Advance the deprecated counter for every product in the `deprecated` status and trash
	 * those past the threshold.
	 *
	 * This is the ONLY place the counter increments — running it once per full-sync finalize keeps
	 * it reliable against the change-gate (which skips unchanged products before get_status()). The
	 * counter starts at 0, so threshold 0 removes on the first pass; removal moves to trash only.
	 *
	 * @param int                             $threshold        Configured deprecated_remove_after_syncs (0 = immediate).
	 * @param Skwirrel_WC_Sync_Product_Mapper $mapper           For the external-id meta key.
	 * @param int                             $sync_started_at  Unix start time of this run; guards against a
	 *                                                          re-run of step_finalize double-ticking counters.
	 * @param string                          $run_id           Current run uuid, for the deep-link marker.
	 * @param float|null                      $deadline         Wall-clock budget; when it passes with work left
	 *                                                          the pass yields and reports `complete => false`.
	 *                                                          Null runs to completion (synchronous path).
	 * @return array{trashed:int, complete:bool} Posts moved to trash (parents + their variations), and
	 *                                           whether the whole deprecated set was processed.
	 */
	public function escalate_deprecated( int $threshold, Skwirrel_WC_Sync_Product_Mapper $mapper, int $sync_started_at, string $run_id = '', ?float $deadline = null ): array {
		$external_id_meta = $mapper->get_external_id_meta_key();
		$grouped_meta     = Skwirrel_WC_Sync_Product_Lookup::GROUPED_PRODUCT_ID_META;
		$count_meta       = Skwirrel_WC_Sync_Deprecated_Status::COUNT_META;
		$ticked_meta      = Skwirrel_WC_Sync_Deprecated_Status::TICKED_META;
		$status           = Skwirrel_WC_Sync_Deprecated_Status::STATUS;

		// Skwirrel-managed products/variations currently in the deprecated status. Variations are
		// included so an orphaned stale variation (marked deprecated while its parent stays present)
		// still escalates; a trashed variable parent additionally cascades to its own variations.
		//
		// Fetched in bounded batches rather than posts_per_page => -1: on a store with a large
		// discontinued catalogue, loading every id and then writing to each in one pass made a
		// supposedly bounded async step run until it hit a worker or memory limit, and a retry
		// restarted the whole pass. No cursor is needed because the batch is self-consuming —
		// each product processed here is either stamped with this run's tick (excluded by the
		// meta_query below) or leaves the deprecated status entirely.
		$batch_size = (int) apply_filters( 'skwirrel_wc_sync_deprecated_batch_size', self::DEPRECATED_BATCH_SIZE );
		$batch_size = max( 1, $batch_size );
		$trashed    = 0;

		do {
			$ids = get_posts(
				[
					'post_type'      => [ 'product', 'product_variation' ],
					'post_status'    => $status,
					'fields'         => 'ids',
					'posts_per_page' => $batch_size,
					'no_found_rows'  => true,
					// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- bounded to deprecated-status posts; only Skwirrel-managed items carry these keys.
					'meta_query'     => [
						'relation' => 'AND',
						[
							'relation' => 'OR',
							[
								'key'     => $external_id_meta,
								'value'   => '',
								'compare' => '!=',
							],
							[
								'key'     => $grouped_meta,
								'value'   => '',
								'compare' => '!=',
							],
						],
						// Not yet advanced during THIS run — the self-consuming part of the cursor.
						[
							'relation' => 'OR',
							[
								'key'     => $ticked_meta,
								'compare' => 'NOT EXISTS',
							],
							[
								'key'     => $ticked_meta,
								'value'   => $sync_started_at,
								'type'    => 'NUMERIC',
								'compare' => '<',
							],
						],
					],
				]
			);

			$ids = array_map( 'intval', (array) $ids );
			if ( empty( $ids ) ) {
				return [
					'trashed'  => $trashed,
					'complete' => true,
				];
			}

			$batch    = $this->escalate_deprecated_batch( $ids, $threshold, $sync_started_at, $run_id, $count_meta, $ticked_meta, $status );
			$trashed += $batch['trashed'];

			// A batch that acted on nothing would be returned again forever (e.g. a post stuck in the
			// deprecated status whose WC product cannot be loaded). Stop rather than spin.
			if ( 0 === $batch['processed'] ) {
				$this->logger->warning(
					'Deprecated escalation made no progress on a batch — stopping this pass',
					[ 'batch_size' => count( $ids ) ]
				);
				return [
					'trashed'  => $trashed,
					'complete' => true,
				];
			}

			if ( null !== $deadline && microtime( true ) >= $deadline ) {
				return [
					'trashed'  => $trashed,
					'complete' => false,
				];
			}
		} while ( true );
	}

	/**
	 * Advance (or remove) one batch of deprecated products.
	 *
	 * @param array<int, int> $ids             Post IDs currently in the deprecated status.
	 * @param int             $threshold       Configured deprecated_remove_after_syncs (0 = immediate).
	 * @param int             $sync_started_at Unix start time of this run.
	 * @param string          $run_id          Current run uuid.
	 * @param string          $count_meta      Deprecated counter meta key.
	 * @param string          $ticked_meta     Deprecated "ticked during run" meta key.
	 * @param string          $status          The deprecated post status.
	 * @return array{trashed:int, processed:int} Posts trashed, and posts this batch actually acted on.
	 */
	private function escalate_deprecated_batch( array $ids, int $threshold, int $sync_started_at, string $run_id, string $count_meta, string $ticked_meta, string $status ): array {
		$trashed   = 0;
		$processed = 0;
		foreach ( $ids as $post_id ) {
			$product = wc_get_product( $post_id );
			// Skip anything no longer deprecated — e.g. a variation already cascade-trashed earlier in
			// this same loop by its parent — so we neither re-tick nor re-add meta to it.
			if ( ! $product || $status !== $product->get_status() ) {
				continue;
			}
			// Resume idempotency: skip products already advanced during THIS run, so a re-run of
			// step_finalize after a crash does not double-count and trash a product early.
			if ( (int) get_post_meta( $post_id, $ticked_meta, true ) >= $sync_started_at ) {
				continue;
			}

			$count  = (int) get_post_meta( $post_id, $count_meta, true );
			$result = Skwirrel_WC_Sync_Deprecated_Status::escalate( $count, $threshold );

			if ( ! $result['remove'] ) {
				update_post_meta( $post_id, $count_meta, $result['count'] );
				update_post_meta( $post_id, $ticked_meta, $sync_started_at );
				++$processed;
				continue;
			}
			++$processed;

			$product->set_status( 'trash' );
			$product->save();
			delete_post_meta( $post_id, $count_meta );
			delete_post_meta( $post_id, $ticked_meta );
			// Invalidate every change gate so a later unchanged reappearance is reprocessed (and revived).
			Skwirrel_WC_Sync_Product_Upserter::invalidate_change_gates( (int) $post_id );
			Skwirrel_WC_Sync_Run_Links::mark_trashed( (int) $post_id, $run_id );
			++$trashed;

			// Variable product: cascade the trash to variations and clear their counters too.
			if ( $product->is_type( 'variable' ) ) {
				foreach ( $product->get_children() as $vid ) {
					$variation = wc_get_product( $vid );
					if ( $variation && 'trash' !== $variation->get_status() ) {
						$variation->set_status( 'trash' );
						$variation->save();
						Skwirrel_WC_Sync_Run_Links::mark_trashed( (int) $vid, $run_id );
						++$trashed;
					}
					delete_post_meta( (int) $vid, $count_meta );
					delete_post_meta( (int) $vid, $ticked_meta );
					Skwirrel_WC_Sync_Product_Upserter::invalidate_change_gates( (int) $vid );
				}
			}
		}

		if ( $trashed > 0 ) {
			$this->logger->info(
				'Deprecated products past threshold moved to trash',
				[
					'count'     => $trashed,
					'threshold' => $threshold,
				]
			);
		}
		return [
			'trashed'   => $trashed,
			'processed' => $processed,
		];
	}

	/**
	 * Purge stale categories that are no longer present in Skwirrel.
	 *
	 * Compares all WooCommerce product_cat terms that have _skwirrel_category_id term meta
	 * against the list of category IDs seen during the current sync run. Categories not
	 * in the seen list are deleted, unless they still have non-trashed products assigned
	 * (safety check to prevent data loss).
	 *
	 * @param string[] $seen_category_ids Skwirrel category IDs that were encountered during sync.
	 * @return int Number of categories deleted.
	 */
	public function purge_stale_categories( array $seen_category_ids ): int {
		global $wpdb;
		$cat_meta_key = Skwirrel_WC_Sync_Product_Mapper::CATEGORY_ID_META;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$all_skwirrel_terms = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT tm.term_id, tm.meta_value as skwirrel_id, t.name as term_name
             FROM {$wpdb->termmeta} tm
             INNER JOIN {$wpdb->term_taxonomy} tt ON tm.term_id = tt.term_id AND tt.taxonomy = 'product_cat'
             INNER JOIN {$wpdb->terms} t ON tm.term_id = t.term_id
             WHERE tm.meta_key = %s AND tm.meta_value != ''",
				$cat_meta_key
			)
		);

		$seen   = array_unique( $seen_category_ids );
		$purged = 0;

		foreach ( $all_skwirrel_terms as $term ) {
			if ( in_array( $term->skwirrel_id, $seen, true ) ) {
				continue;
			}

			// Safety check: do not delete if products are still assigned to this category
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$product_count = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$wpdb->term_relationships} tr
                 INNER JOIN {$wpdb->posts} p ON tr.object_id = p.ID
                     AND p.post_type IN ('product', 'product_variation')
                     AND p.post_status NOT IN ('trash', 'auto-draft')
                 WHERE tr.term_taxonomy_id = (
                     SELECT term_taxonomy_id FROM {$wpdb->term_taxonomy}
                     WHERE term_id = %d AND taxonomy = 'product_cat'
                 )",
					$term->term_id
				)
			);

			if ( $product_count > 0 ) {
				$this->logger->warning(
					'Category not deleted: products still assigned',
					[
						'term_id'       => $term->term_id,
						'name'          => $term->term_name,
						'skwirrel_id'   => $term->skwirrel_id,
						'product_count' => $product_count,
					]
				);
				continue;
			}

			$this->logger->info(
				'Category removed from Skwirrel, cleaned up',
				[
					'term_id'     => $term->term_id,
					'name'        => $term->term_name,
					'skwirrel_id' => $term->skwirrel_id,
				]
			);
			wp_delete_term( (int) $term->term_id, 'product_cat' );
			++$purged;
		}

		if ( $purged > 0 ) {
			$this->logger->info( 'Stale categories cleaned up', [ 'count' => $purged ] );
		}

		return $purged;
	}
}
